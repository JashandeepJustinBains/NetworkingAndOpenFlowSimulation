#!/bin/bash

python3 network_emulator.py "$@"
