#!/bin/bash

python3 sender.py "$@"