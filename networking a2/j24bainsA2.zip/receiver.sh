#!/bin/bash

python3 receiver.py "$@"