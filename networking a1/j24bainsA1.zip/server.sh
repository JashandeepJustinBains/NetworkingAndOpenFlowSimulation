#!/bin/bash

python server.py $1
