#!/bin/bash

python client.py "$@"
